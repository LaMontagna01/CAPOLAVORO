document.addEventListener("DOMContentLoaded",function(){

    document.querySelector(".ButtAccedi").addEventListener("click",function(){

    
        if (localStorage.getItem("VettoreUtenti") == null || localStorage.getItem("VettoreUtenti") == "") {
           
            localStorage.clear();
            localStorage.setItem("VettoreUtenti", JSON.stringify(utenti));
        }
        controlli();

    })

    //vedi password
    let checkBox = document.querySelector(".vediPassword");
    checkBox.addEventListener("click",function(){

        let input = document.querySelector(".pass");

        if(this.checked){
            input.type= "text";
            //checkBox.src = "../occhio/aperto.PNG";
        }
        else{
            input.type= "password";
            //checkBox.src = "../occhio/chiuso.PNG";
        }
        //non visualizza l'immagine assegnata
        console.log("SRC IMMAGINE PER CHECKBOX");
        console.log(checkBox.src);
    })
})

function controlli() {
    
    //valori dei due input
    let nome = document.querySelector(".nome").value;
    let password = document.querySelector(".pass").value;

    utenti = JSON.parse(localStorage.getItem("VettoreUtenti"));
    //vettore degli utenti
    console.log(utenti);

    ////////////////////////////////////////////////////////////////////////////////////////
    //CONTROLLI CON REGEX

    //controllo se stringhe vuote
    if(nome=="" || password==""){
        alert("Per favore, inserisci un nome e una password");
        return;
    }

    //copntrollo se presenti spazi
    const RegexSpazio = /\s/;
    if(RegexSpazio.test(nome) || RegexSpazio.test(password)){
        alert("Per favore, non inserire spazi");
        return;
    }

    // ^ = inizio di una stringa
    // $ = fine di una stringa
    // {n,} = deve essere lungua più uguale a n

    //controllo nome
    let regexNome = /^[a-zA-Z]{3,}$/
    if(!regexNome.test(nome)){
        alert("inserisci almeno 3 lettere per il nome");
        return;
    }

    //controllo password
    let regexPassword8Carat = /^[a-zA-Z0-9]{8,}$/
    let regexPasswordAlmenoMaiuscola = /[A-Z]/
    if(!regexPassword8Carat.test(password)){
        alert("inserisci almeno 8 lettere per la password");
        return;
    }
    else if(!regexPasswordAlmenoMaiuscola.test(password)){
        alert("inserisci almeno una maiuscola per la password");
        return;
    }

    ////////////////////////////////////////////////////////////////////////////////////////
    let user = new Utente(nome,password,null);

    let nuovoUtente=true;

    //for degli utenti
    for (const utente of utenti) {
        
        //utente dentro la lista utenti
        console.log("UTENTE DEL VETTORE UTENTI");
        console.log(utente);

        //utente inserito dalla persona tramite gli input
        console.log("UTENTE DELL'INPUT");
        console.log(user);

        //nome user == nome utente e password user == password utente
        if(user.nome == utente.nome && user.password == utente.password){

            //non è un nuovo utente
            nuovoUtente=false;

            //salvo anche collezione se ce l'ha
            if(utente.collezione != null){

                console.log(localStorage.setItem("Collezione",JSON.stringify(utente.collezione)))
                console.log(localStorage.setItem("Collezione",JSON.stringify(collezione)))

                localStorage.setItem("Collezione",JSON.stringify(utente.collezione));
                let UtenteConCOll = new Utente(nome,password,utente.collezione);
                localStorage.setItem("utente",JSON.stringify(UtenteConCOll));
            }
            //salvo e basta
            else{

                localStorage.setItem("utente",JSON.stringify(user));
            }
 

            alert("Account recuperato");

            break
        }
        //password errata
        else if (nome == utente.nome && password != utente.password){

            alert("Password errata");
            return;
        }


    }

    if(nuovoUtente){

        localStorage.setItem("Collezione",null);

        //metto utente nella lista di utenti
        utenti.push(user);

        console.log("VETTORE DI UTENTI");
        console.log(utenti);

        let vettUtenti = JSON.stringify(utenti);
        localStorage.setItem("VettoreUtenti",vettUtenti)

        //salv l'utente che ha fatto l'accesso
        localStorage.setItem("utente",JSON.stringify(user));


        alert("Account creato")

    }


    //passo alla Home
    window.location.href="../index/Home.html";
}