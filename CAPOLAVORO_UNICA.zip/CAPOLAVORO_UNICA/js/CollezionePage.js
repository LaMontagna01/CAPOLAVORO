document.addEventListener("DOMContentLoaded",function(){

    inizializzaCollezione();

    document.querySelector(".elimina").addEventListener("click",function(){

        controlli();
    })

    document.querySelector(".TornaHome").addEventListener("click",function(){
        window.location.href = "../index/Home.html"
    })
})

function inizializzaCollezione(){

    //prendo i vari div
    let divColl = document.querySelector(".DivCollection");
    let tot = document.querySelector(".totale");

    //riprendo collezione con il JSON
    collezione = JSON.parse(localStorage.getItem("Collezione"));

    //riprendo utente con il JSON
    let user = JSON.parse(localStorage.getItem("utente"));

    //contatore per dare classe univoca al div che contiene manga
    let cont = 0;
    

    if(user.collezione != null){

        //inizializzo i vari manga
        for (const manga of user.collezione) {

            cont++;

            //creo div
            let divManga = document.createElement("div");
            divManga.classList.add("divManga"+cont);

            //creo anche checkBox
            let checkBox = document.createElement("input");
            checkBox.classList.add("checkBOX");
            checkBox.type = "checkbox";
            
            //creo e assegno src immagine
            let immagine = document.createElement("img");
            immagine.src = manga.IMGsrc;



            //se immagine cliccata, porta alla sua "analisi""
            immagine.addEventListener("click",function(){

                //salvo il manga cliccato
                let MangaJSON = JSON.stringify(manga);
                localStorage.setItem("MangaAttuale",MangaJSON);

                window.location.href="../index/Manga.html"
            })

            //appendo
            divManga.appendChild(checkBox);
            divManga.appendChild(immagine);

            //se è presente la data
            if(manga.data != null){

                //la creo
                const stringa = document.createElement("label");
                stringa.innerHTML = "Aggiunto in data: ";

                const aCapo = document.createElement("br");

                let DataDIAggiunta = document.createElement("label");
                DataDIAggiunta.innerHTML = manga.data;

                divManga.appendChild(stringa);
                divManga.appendChild(aCapo);
                divManga.appendChild(DataDIAggiunta);
            }

            divColl.appendChild(divManga);
        }
    }


    //quantità manga
    tot.innerHTML = "In totale hai " + user.collezione.length + " Manga nella tua collezione"

}

function controlli() {
    
    let cont = 0;
    let selezionata = false;

    let user = JSON.parse(localStorage.getItem("utente"));

    //se manga presente nella collezione dell'utente
    for (const manga of user.collezione) {

        cont++;

        //vado a prendere le checkbox
        let divM = document.querySelector(".divManga"+cont)
        let check = divM.querySelector(".checkBOX")
        console.log(check.checked)

        //controllo se checkata
        if(check.checked){
            //togli manga
            selezionata=true;
            togli(manga);
        }
        
    }
    if(!selezionata){
        alert("Checka almeno una checkbox")
    }
    else{

        alert("Manga eliminati dalla tua collezione");

        //ridisegno tutto
        let contenitore = document.querySelector(".DivCollection");
        contenitore.innerHTML="";
        inizializzaCollezione();
    }

    console.log(collezione)
}

function togli(manga) {
    
    //prendo valore localStorage
    collezione = JSON.parse(localStorage.getItem("Collezione"))

    //for del vettore collezione contenente manga
    for (let i = 0; i < collezione.length; i++) {

        
        console.log(collezione[i].nome)
        console.log(manga.nome)
        //controllo dei nomi
        if (collezione[i].nome == manga.nome) {

            //elimino
            collezione.splice(i, 1);

            //salvo nel localStorage
            localStorage.setItem("Collezione", JSON.stringify(collezione));

            //assegno la collezione all'utente
            let utente = JSON.parse(localStorage.getItem("utente"));
            utente.collezione = collezione;

            //SALVO NEL LOCALsTORAGE
            localStorage.setItem("utente",JSON.stringify(utente));
            
            //prendo vettore
            utenti = JSON.parse(localStorage.getItem("VettoreUtenti"));
                
            //sostituisce l'utente senza collezone con la collezione nel vettore utenti
            for (let index = 0; index < utenti.length; index++) {
                if(utenti[index].nome == utente.nome){
                    utenti.splice(index,1,utente);
                    localStorage.setItem("VettoreUtenti",JSON.stringify(utenti))
                }
                        
            }

            break;
        }
    }


}