let collezione = [

    //push dei manga
]