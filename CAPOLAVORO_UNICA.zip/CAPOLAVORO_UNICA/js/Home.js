document.addEventListener("DOMContentLoaded",function(){

    inizializzaBenvenuto();

    inizializzaManga();

    prendiCollezione();

    //bottone per passare a pagina della collezione
    document.querySelector(".bottCollezione").addEventListener("click",function(){

        //se collezione null, non fa nulla
        if(JSON.parse(localStorage.getItem("Collezione")) != null){
            VediCollezione();
        }
        else{
            alert("Per vedere la tua collezione, aggiung almeno un manga")
        }
    })

    //bottone per passare a pagina della creazione del manga
    document.querySelector(".TornaLogin").addEventListener("click",function(){
        
        tornaLogin();
    })

    //input per ricerca approfondita
    document.querySelector(".ricerca").addEventListener("change",function(){

        controllo();
    })

})

function inizializzaBenvenuto() {
    
    //do il benvenuto
    let benvenuto = document.querySelector(".benvenuto");

    let utente = JSON.parse(localStorage.getItem("utente"));

    //cambio frase di benvenuto con nome utente
    benvenuto.textContent += " " + utente.nome;

}

function inizializzaManga() {
    
    //inizializzo tutti i manga 
    let divManga = document.querySelector(".VariManga");


    for (const manga of listaManga) {
        
        let immagine = document.createElement("img");
        immagine.src = manga.IMGsrc;

        //se immagine cliccata, porta alla sua "analisi""
        immagine.addEventListener("click",function(){

            //salvo il manga cliccato
            let MangaJSON = JSON.stringify(manga);
            localStorage.setItem("MangaAttuale",MangaJSON);

            window.location.href="../index/Manga.html"
        })

        divManga.appendChild(immagine);
    }

}

function controllo() {
    
    //prendo valore input e trasformo in una stringa minuscola
    let testoUtente = document.querySelector(".ricerca").value;
    let testoUtenteLower = testoUtente.toLowerCase();

    //controllo se ci sono caratteri corretti
    //regex controlla lettere minuscole, maiuscole e numeri
    let regex = /[a-zA-Z0-9]/;

    //se il testo contiene lettere minuscole
    if(regex.test(testoUtenteLower)){

        //cancello tutti i manga
        let divManga = document.querySelector(".VariManga");
        divManga.innerHTML = "";

        //aggiungo solo quelli che hanno le lettere dall'utente inserite
        for (const manga of listaManga) {
        
            //rende minuscoli tutti i caratteri
            let nomeManga = manga.nome.toLowerCase()
            //controllo se nome manga contiene lettere scritte

            console.log("CONTROLLO SE MANGA HA STESSE LETTERE");
            console.log(nomeManga.match(testoUtenteLower));
            if(nomeManga.match(testoUtenteLower)){

                //creo immagine del manga
                let immagine = document.createElement("img");
                immagine.src = manga.IMGsrc;
        
                //se immagine cliccata, porta alla sua "analisi""
                immagine.addEventListener("click",function(){
        
                    //salvo il manga cliccato
                    let MangaJSON = JSON.stringify(manga);
                    localStorage.setItem("MangaAttuale",MangaJSON);
        
                    window.location.href="../index/Manga.html"
                })
        
                divManga.appendChild(immagine);
            }
        }
    }

    else if(testoUtente==""){
        //cancello tutti i manga
        let divManga = document.querySelector(".VariManga");
        divManga.innerHTML = "";

        //e poi gli inserisco tutti
        inizializzaManga();
    }

    else{
        alert("Inserisci dei caratteri validi");
    }

}

function prendiCollezione() {
    
    //controllo personale del contenuto della collezione
    collezione = JSON.parse(localStorage.getItem("Collezione"));

    console.log("COLLEZIONE");
    console.log(collezione);
}

///////////////////////PASSA AD ALTRE PAGINE////////////////////////////////////////////////
function VediCollezione() {
    
    window.location.href="../index/VediCollezione.html";
}

function tornaLogin() {
    
    window.location.href="../index/Account.html";
}