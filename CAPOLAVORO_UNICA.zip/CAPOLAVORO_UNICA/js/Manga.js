class Manga{

    constructor(nome,autore,n_volumi,stato,genere,trama, IMGsrc, data){

        this.nome=nome;
        this.autore=autore;
        this.n_volumi=n_volumi;  //int
        this.stato=stato;  //true = finito
        this.genere=genere;
        this.trama=trama;

        //per assegnare immagine
        this.IMGsrc=IMGsrc;

        if(data!=null){
            this.data=data; //data di aggiunta alla collezione
        }
    }
}