document.addEventListener("DOMContentLoaded",function(){

    let manga = JSON.parse(localStorage.getItem("MangaAttuale"))
    let USER = JSON.parse(localStorage.getItem("utente"))

    if (JSON.parse(localStorage.getItem("Collezione")) == null || USER.collezione == null ) {
        localStorage.setItem("Collezione", JSON.stringify([]));
    }
    
    //assegno immagine
    let img = document.querySelector(".immagine");
    img.src = manga.IMGsrc;

    //assegno titolo
    let titolo = document.querySelector(".titolo");
    titolo.innerHTML += manga.nome;

    //assegno nome
    let nom = document.querySelector(".nom")
    nom.innerHTML += manga.nome

    //assegno autor
    let autor = document.querySelector(".autore")
    autor.innerHTML += manga.autore

    //assegno generi
    let generi = document.querySelector(".genere")
    generi.innerHTML += manga.genere
    
    //assegno volumi
    let volumi = document.querySelector(".volumi")
    volumi.innerHTML += manga.n_volumi
    
    //assegno stato
    let stato = document.querySelector(".stato")
    if(manga.stato){
        stato.innerHTML += "Finito";
    }
    else{
        stato.innerHTML += "In corso";
    }

    //assegno trama
    let trama = document.querySelector(".trama")
    trama.innerHTML += manga.trama


    //bottone per aggiungere manga a collezione
    document.querySelector(".aggiungi").addEventListener("click",function(){

        aggiungi(manga);
    })
    
    //bottone per togliere manga da collezione
    document.querySelector(".togli").addEventListener("click",function(){
            
        togli(manga);
    })

    //bottone per tornare alla home
    document.querySelector(".home").addEventListener("click",function(){
            
        window.location.href="../index/Home.html"
    })

})

function aggiungi(manga) {
    
    let presente = false;

    collezione = JSON.parse(localStorage.getItem("Collezione"))

    let oggi = creaGiorno();

    //assegno anche la data in cui è stato aggiunto
    let mangaConData = new Manga(manga.nome,manga.autore,manga.n_volumi,manga.stato,manga.genere,manga.trama,manga.IMGsrc,oggi)
                            // nome     autore        n_volumi      stato      genere       trama       img          data

    for (const MangaAttuale of collezione) {
        
        //controllo se manga già presente in collezione
        if(MangaAttuale.nome == mangaConData.nome){

            presente = true
            alert("Manga già presente in collezione")
        }
    }

    if(!presente){

        //aggiungo manga alla collezione
        collezione.push(mangaConData);
        localStorage.setItem("Collezione",JSON.stringify(collezione));

        alert("Manga inserito nella tua collezione")
    }

    //collezione
    console.log("COLLEZIONE");
    console.log(collezione);

    //prendo localStorage utente
    let utente = JSON.parse(localStorage.getItem("utente"));
    console.log(utente);

    //creo nuovo utente e gli assegno valori localStorage + collezione
    let user = new Utente(utente.nome, utente.password, collezione);
    localStorage.setItem("utente",JSON.stringify(user));

    //prendo vettore utenti da localStorage
    utenti = JSON.parse(localStorage.getItem("VettoreUtenti"));
    console.log(utenti);

    //sostituisce l'utente senza collezone con la collezione nel vettore utenti
    for (let index = 0; index < utenti.length; index++) {
        if(utenti[index].nome == user.nome){
            utenti.splice(index,1,user);
            localStorage.setItem("VettoreUtenti",JSON.stringify(utenti))
        }
        
    }

    console.log("UTENTE");
    console.log(user);
}

function togli(manga) {
    
    let presente = false;

    collezione = JSON.parse(localStorage.getItem("Collezione"))

    //for del vettore collezione contenente manga
    for (let i = 0; i < collezione.length; i++) {

        //controllo dei nomi
        if (collezione[i].nome == manga.nome) {

            //elimino
            collezione.splice(i, 1);

            //salvo nel localStorage
            localStorage.setItem("Collezione", JSON.stringify(collezione));
            alert("Manga eliminato dalla tua collezione");

            console.log(collezione)

                //prendo localStorage utente
            let utente = JSON.parse(localStorage.getItem("utente"));
            console.log(utente);

            //creo nuovo utente e gli assegno valori localStorage + collezione
            let user = new Utente(utente.nome, utente.password, collezione);
            localStorage.setItem("utente",JSON.stringify(user));

            utenti = JSON.parse(localStorage.getItem("VettoreUtenti"));

            //sostituisce l'utente senza collezone con la collezione nel vettore utenti
            for (let index = 0; index < utenti.length; index++) {
                if(utenti[index].nome == user.nome){
                    utenti.splice(index,1,user);
                    localStorage.setItem("VettoreUtenti",JSON.stringify(utenti))
                }
        
            }

            presente = true;
            break;
        }
    }

    if(!presente){

        alert("Manga non presente nella tua collezione")
    }

    console.log("COLLEZIONE");
    console.log(collezione);
    //setto localStorage

    //prendo localStorage utente
    let utente = JSON.parse(localStorage.getItem("utente"));
    
    //creo nuovo utente e gli assegno valori localStorage + collezione
    let user = new Utente(utente.nome, utente.password, collezione);
    localStorage.setItem("utente",JSON.stringify(user));
    
    console.log("UTENTE");
    console.log(user);
}

function creaGiorno() {
    
    //prendo oggi
    let oggi = new Date();
    const giorno = oggi.getDate();
    const mese = oggi.getMonth()+1;
    const anno = oggi.getFullYear();

    console.log(giorno+"/"+mese+"/"+anno);

    return giorno+"/"+mese+"/"+anno;
}
