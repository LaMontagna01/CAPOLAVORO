class Utente {

    constructor(nome,password,collezione){
        this.nome=nome;
        this.password=password;

        if(collezione!=null){
            this.collezione=collezione
        }
    }

    
}